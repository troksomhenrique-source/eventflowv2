-- =============================================================
-- EventFlow · 0003 · Row Level Security pelos três perfis
--   gerência → tudo
--   produção → OS, memoriais, logística, VT e 3D; lê o pipeline, não vê preço
--   estoque  → inventário, frota, ordens de carga e movimentos; não vê preço
-- =============================================================

do $$
declare t text;
begin
  foreach t in array array[
    'perfis','clientes','itens','kits','kit_itens','frota',
    'negocios','negocio_sala','briefing_blocos','briefing_notas',
    'visitas_tecnicas','vt_participantes','vt_checklist','vt_fotos','projetos_3d',
    'orcamentos','orcamento_linhas','fechamentos','fechamento_participantes','fechamento_pauta',
    'ordens_venda','os_produtores','os_itens','os_ancoragens','os_memorial',
    'os_logistica','os_viagens','viagem_equipe',
    'ordens_carga','osc_itens','movimentos','movimento_linhas',
    'compromissos','compromisso_responsaveis','notas','nota_checklist',
    'canais','canal_membros','mensagens','posts','post_curtidas','post_comentarios',
    'notificacoes','notificacao_leituras'
  ] loop
    execute format('alter table %I enable row level security', t);
  end loop;
end $$;

-- ---------- atalhos ----------
-- leitura_geral: qualquer pessoa autenticada da operação enxerga
-- escrita_gerencia / escrita_producao / escrita_estoque: quem pode alterar

-- ===== pessoas =====
create policy perfis_leitura on perfis for select to authenticated using (true);
create policy perfis_eu     on perfis for update to authenticated using (id = auth.uid()) with check (id = auth.uid());
create policy perfis_admin  on perfis for all    to authenticated using (e_gerencia()) with check (e_gerencia());

-- ===== cadastros =====
create policy clientes_le    on clientes for select to authenticated using (true);
create policy clientes_grava on clientes for all    to authenticated using (e_gerencia()) with check (e_gerencia());

-- Inventário: todos leem (a produção precisa montar escopo), estoque e gerência escrevem.
create policy itens_le    on itens for select to authenticated using (true);
create policy itens_grava on itens for all    to authenticated
  using (e_gerencia() or e_estoque()) with check (e_gerencia() or e_estoque());

create policy kits_le      on kits      for select to authenticated using (true);
create policy kits_grava   on kits      for all    to authenticated using (e_gerencia() or e_estoque()) with check (e_gerencia() or e_estoque());
create policy kititens_le  on kit_itens for select to authenticated using (true);
create policy kititens_gr  on kit_itens for all    to authenticated using (e_gerencia() or e_estoque()) with check (e_gerencia() or e_estoque());

create policy frota_le    on frota for select to authenticated using (true);
create policy frota_grava on frota for all    to authenticated using (e_gerencia() or e_estoque()) with check (e_gerencia() or e_estoque());

-- ===== pipeline comercial =====
-- Produção acompanha o pipeline (precisa do briefing e da VT), mas só a gerência muda o negócio.
create policy negocios_le    on negocios for select to authenticated using (e_gerencia() or e_producao());
create policy negocios_grava on negocios for all    to authenticated using (e_gerencia()) with check (e_gerencia());

create policy sala_le    on negocio_sala for select to authenticated using (e_gerencia() or e_producao());
create policy sala_grava on negocio_sala for all    to authenticated
  using (e_gerencia() or e_producao()) with check (e_gerencia() or e_producao());
comment on policy sala_grava on negocio_sala is 'A produção corrige as medidas da sala na visita técnica.';

create policy brief_le    on briefing_blocos for select to authenticated using (e_gerencia() or e_producao());
create policy brief_grava on briefing_blocos for all    to authenticated using (e_gerencia()) with check (e_gerencia());
create policy briefn_le    on briefing_notas for select to authenticated using (e_gerencia() or e_producao());
create policy briefn_grava on briefing_notas for all    to authenticated using (e_gerencia()) with check (e_gerencia());

-- Visita técnica e 3D são trabalho da produção.
create policy vt_le    on visitas_tecnicas for select to authenticated using (e_gerencia() or e_producao());
create policy vt_grava on visitas_tecnicas for all    to authenticated
  using (e_gerencia() or e_producao()) with check (e_gerencia() or e_producao());
create policy vtp_le    on vt_participantes for select to authenticated using (e_gerencia() or e_producao());
create policy vtp_grava on vt_participantes for all    to authenticated using (e_gerencia() or e_producao()) with check (e_gerencia() or e_producao());
create policy vtc_le    on vt_checklist for select to authenticated using (e_gerencia() or e_producao());
create policy vtc_grava on vt_checklist for all    to authenticated using (e_gerencia() or e_producao()) with check (e_gerencia() or e_producao());
create policy vtf_le    on vt_fotos for select to authenticated using (e_gerencia() or e_producao());
create policy vtf_grava on vt_fotos for all    to authenticated using (e_gerencia() or e_producao()) with check (e_gerencia() or e_producao());

create policy tresd_le    on projetos_3d for select to authenticated using (e_gerencia() or e_producao());
create policy tresd_grava on projetos_3d for all    to authenticated using (e_gerencia() or e_producao()) with check (e_gerencia() or e_producao());

-- Orçamento e fechamento: só a gerência, inclusive para ler. É aqui que mora o preço.
create policy orc_gerencia     on orcamentos        for all to authenticated using (e_gerencia()) with check (e_gerencia());
create policy orclin_gerencia  on orcamento_linhas  for all to authenticated using (e_gerencia()) with check (e_gerencia());
create policy fech_gerencia    on fechamentos       for all to authenticated using (e_gerencia()) with check (e_gerencia());
create policy fechp_gerencia   on fechamento_participantes for all to authenticated using (e_gerencia()) with check (e_gerencia());
create policy fechpa_gerencia  on fechamento_pauta  for all to authenticated using (e_gerencia()) with check (e_gerencia());

-- ===== ordens de venda =====
create policy os_le    on ordens_venda for select to authenticated using (true);
create policy os_gerencia on ordens_venda for all to authenticated using (e_gerencia()) with check (e_gerencia());
-- A produção altera a própria OS: status, descritivo, escopo — mas não o valor.
create policy os_producao on ordens_venda for update to authenticated
  using (e_producao() and exists (select 1 from os_produtores p where p.os_id = ordens_venda.id and p.perfil_id = auth.uid()))
  with check (e_producao());

create policy osprod_le    on os_produtores for select to authenticated using (true);
create policy osprod_grava on os_produtores for all    to authenticated using (e_gerencia()) with check (e_gerencia());

-- Escopo, pontos de ancoragem, memorial e logística são da produção.
create policy ositens_le    on os_itens for select to authenticated using (true);
create policy ositens_grava on os_itens for all    to authenticated
  using (e_gerencia() or e_producao()) with check (e_gerencia() or e_producao());

create policy anc_le    on os_ancoragens for select to authenticated using (true);
create policy anc_grava on os_ancoragens for all    to authenticated using (e_gerencia() or e_producao()) with check (e_gerencia() or e_producao());

create policy mem_le    on os_memorial for select to authenticated using (true);
create policy mem_grava on os_memorial for all    to authenticated using (e_gerencia() or e_producao()) with check (e_gerencia() or e_producao());

create policy log_le    on os_logistica for select to authenticated using (true);
create policy log_grava on os_logistica for all    to authenticated using (e_gerencia() or e_producao()) with check (e_gerencia() or e_producao());
create policy viag_le    on os_viagens for select to authenticated using (true);
create policy viag_grava on os_viagens for all    to authenticated using (e_gerencia() or e_producao()) with check (e_gerencia() or e_producao());
create policy vieq_le    on viagem_equipe for select to authenticated using (true);
create policy vieq_grava on viagem_equipe for all    to authenticated using (e_gerencia() or e_producao()) with check (e_gerencia() or e_producao());
comment on policy viag_le on os_viagens is 'O estoque precisa ler para saber que veículo encosta na doca.';

-- ===== ordens de carga e movimentos =====
create policy oc_le    on ordens_carga for select to authenticated using (true);
create policy oc_grava on ordens_carga for all    to authenticated
  using (e_gerencia() or e_estoque() or e_producao()) with check (e_gerencia() or e_estoque() or e_producao());
create policy osci_le    on osc_itens for select to authenticated using (true);
create policy osci_grava on osc_itens for all    to authenticated using (e_gerencia() or e_estoque() or e_producao()) with check (e_gerencia() or e_estoque() or e_producao());

-- Movimento é livro razão: escreve-se pelas funções confirmar_carga / registrar_descarga.
create policy mov_le  on movimentos       for select to authenticated using (true);
create policy movl_le on movimento_linhas for select to authenticated using (true);

-- ===== agenda, notas e comunicação =====
create policy comp_le    on compromissos for select to authenticated using (true);
create policy comp_grava on compromissos for all    to authenticated using (true) with check (true);
create policy compr_le    on compromisso_responsaveis for select to authenticated using (true);
create policy compr_grava on compromisso_responsaveis for all to authenticated using (true) with check (true);

create policy notas_le on notas for select to authenticated
  using (escopo = 'equipe' or autor_id = auth.uid());
create policy notas_grava on notas for all to authenticated
  using (autor_id = auth.uid() or e_gerencia()) with check (autor_id = auth.uid() or e_gerencia());
create policy notac_le on nota_checklist for select to authenticated
  using (exists (select 1 from notas n where n.id = nota_id and (n.escopo = 'equipe' or n.autor_id = auth.uid())));
create policy notac_grava on nota_checklist for all to authenticated
  using (exists (select 1 from notas n where n.id = nota_id and (n.autor_id = auth.uid() or e_gerencia())))
  with check (exists (select 1 from notas n where n.id = nota_id and (n.autor_id = auth.uid() or e_gerencia())));

-- Conversa: só quem é membro do canal.
create policy canais_le on canais for select to authenticated
  using (exists (select 1 from canal_membros m where m.canal_id = canais.id and m.perfil_id = auth.uid()));
create policy canais_grava on canais for all to authenticated using (e_gerencia()) with check (e_gerencia());
create policy membros_le on canal_membros for select to authenticated using (true);
create policy membros_eu on canal_membros for update to authenticated
  using (perfil_id = auth.uid()) with check (perfil_id = auth.uid());
create policy membros_admin on canal_membros for all to authenticated using (e_gerencia()) with check (e_gerencia());

create policy msg_le on mensagens for select to authenticated
  using (exists (select 1 from canal_membros m where m.canal_id = mensagens.canal_id and m.perfil_id = auth.uid()));
create policy msg_envia on mensagens for insert to authenticated
  with check (autor_id = auth.uid()
    and exists (select 1 from canal_membros m where m.canal_id = mensagens.canal_id and m.perfil_id = auth.uid()));
create policy msg_edita on mensagens for update to authenticated
  using (autor_id = auth.uid()) with check (autor_id = auth.uid());

create policy posts_le    on posts for select to authenticated using (true);
create policy posts_cria  on posts for insert to authenticated with check (autor_id = auth.uid());
create policy posts_meu   on posts for update to authenticated using (autor_id = auth.uid()) with check (autor_id = auth.uid());
create policy posts_apaga on posts for delete to authenticated using (autor_id = auth.uid() or e_gerencia());
create policy curte_le    on post_curtidas for select to authenticated using (true);
create policy curte_eu    on post_curtidas for all to authenticated using (perfil_id = auth.uid()) with check (perfil_id = auth.uid());
create policy coment_le   on post_comentarios for select to authenticated using (true);
create policy coment_meu  on post_comentarios for all to authenticated
  using (autor_id = auth.uid() or e_gerencia()) with check (autor_id = auth.uid() or e_gerencia());

create policy notif_le on notificacoes for select to authenticated using (meu_papel() = any(destino));
create policy notif_cria on notificacoes for insert to authenticated with check (true);
create policy notifl_eu on notificacao_leituras for all to authenticated
  using (perfil_id = auth.uid()) with check (perfil_id = auth.uid());

-- ===============================================================
-- Preço
-- RLS filtra linha, não coluna — e no Supabase todo mundo chega como
-- o mesmo papel de banco (authenticated), então GRANT por coluna não
-- separa gerência de produção. A saída é ler por uma view que apaga o
-- valor para quem não é gerência, e fechar a tabela crua.
-- ===============================================================

revoke select on itens        from authenticated;
revoke select on ordens_venda from authenticated;

create or replace view v_itens with (security_invoker = true) as
  select cod, nome, categoria, unidade, peso_kg, por_case, watts,
         quantidade_total, em_manutencao, ativo, criado_em,
         case when e_gerencia() then diaria end as diaria
    from itens;
comment on view v_itens is 'Catálogo como o app lê. A diária só aparece para a gerência.';

create or replace view v_ordens_venda with (security_invoker = true) as
  select id, codigo, negocio_id, cliente_id, evento, local_nome, cidade, publico, area_m2,
         montagem, evento_inicio, evento_fim, desmontagem, status, descritivo, criado_em,
         case when e_gerencia() then valor end as valor
    from ordens_venda;
comment on view v_ordens_venda is 'OS como o app lê. O valor do contrato só aparece para a gerência.';

create or replace view v_kits_com_diaria with (security_invoker = true) as
  select k.cod, k.nome, k.categoria, k.observacao,
         sum(ki.quantidade)                                              as pecas,
         sum(ceil(ki.quantidade::numeric / greatest(i.por_case,1)))::int as cases,
         sum(i.peso_kg * ki.quantidade)                                  as peso_kgf,
         sum(i.watts   * ki.quantidade)                                  as consumo_w,
         case when e_gerencia() then sum(i.diaria * ki.quantidade) end   as diaria_total
    from kits k
    join kit_itens ki on ki.kit_cod = k.cod
    join itens     i  on i.cod = ki.item_cod
   group by k.cod, k.nome, k.categoria, k.observacao;

grant select on v_itens, v_ordens_venda, v_kits_com_diaria to authenticated;
grant insert, update, delete on itens        to authenticated;
grant insert, update, delete on ordens_venda to authenticated;

-- As funções de disponibilidade leem itens por dentro (stable, sem coluna de preço),
-- então continuam funcionando para os três perfis.
grant execute on function disponibilidade(date, date)            to authenticated;
grant execute on function disponivel(text, date, date, uuid)     to authenticated;
grant execute on function reservado(text, date, date, uuid)      to authenticated;
grant execute on function veiculo_livre(text, date, date, uuid)  to authenticated;
grant execute on function confirmar_carga(uuid)                  to authenticated;
grant execute on function registrar_descarga(uuid, jsonb)        to authenticated;
grant execute on function gerar_ordem_carga(uuid)                to authenticated;
