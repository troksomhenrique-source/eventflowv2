-- =============================================================
-- EventFlow · ERP + CRM para locadora de eventos
-- 0001 · tipos e tabelas
-- =============================================================
create extension if not exists "pgcrypto";
create extension if not exists "btree_gist";

-- ---------- tipos ----------
create type papel            as enum ('gerencia','producao','estoque');
create type categoria_item   as enum ('Estrutura','Som','Luz','Vídeo','Cenografia','Internet','Extras');
create type etapa_negocio    as enum ('qualificacao','briefing','vt','tresd','orcamento','fechamento','finalizacao');
create type temperatura_lead as enum ('quente','morno','frio');
create type bloco_briefing   as enum ('led','palco','estrutura','som','luz','transmissao','cenografia','internet');
create type ancoragem_sala   as enum ('sim','nao','confirmar');
create type status_3d        as enum ('Não solicitado','Em produção','Enviado ao cliente','Aprovado','Reprovado');
create type tipo_linha_orc   as enum ('estoque','externo');
create type cobranca_linha   as enum ('diaria','fechado');
create type status_os        as enum ('Aguardando produção','Em produção','Liberada','Encerrada');
create type status_carga     as enum ('Liberada','Em separação','Carregada','Retornada');
create type tipo_movimento   as enum ('SAIDA','ENTRADA');
create type escopo_nota      as enum ('equipe','privada');
create type tipo_canal       as enum ('canal','os','dm');

-- ---------- pessoas ----------
create table perfis (
  id          uuid primary key references auth.users(id) on delete cascade,
  nome        text not null,
  cargo       text,
  papel       papel not null default 'producao',
  cor         text  default '#1B1B1E',
  ativo       boolean not null default true,
  criado_em   timestamptz not null default now()
);
comment on table perfis is 'Espelha auth.users e carrega o papel que governa o RLS.';

-- ---------- cadastros ----------
create table clientes (
  id         uuid primary key default gen_random_uuid(),
  nome       text not null,
  tipo       text,
  documento  text,
  contato    text,
  telefone   text,
  cidade     text,
  desde      text,
  criado_em  timestamptz not null default now()
);

create table itens (
  cod              text primary key,
  nome             text not null,
  categoria        categoria_item not null,
  unidade          text not null default 'pç',
  peso_kg          numeric(10,2) not null default 0 check (peso_kg >= 0),
  por_case         integer not null default 1 check (por_case >= 1),
  watts            integer not null default 0 check (watts >= 0),
  diaria           numeric(12,2) not null default 0 check (diaria >= 0),
  quantidade_total integer not null default 0 check (quantidade_total >= 0),
  em_manutencao    integer not null default 0 check (em_manutencao >= 0),
  ativo            boolean not null default true,
  criado_em        timestamptz not null default now(),
  constraint manutencao_cabe check (em_manutencao <= quantidade_total)
);
comment on column itens.por_case is 'Quantas unidades vão em um case — base da volumetria da carga.';
comment on column itens.watts   is 'Consumo unitário, usado para dimensionar gerador.';

create table kits (
  cod        text primary key,
  nome       text not null,
  categoria  categoria_item not null,
  observacao text
);
create table kit_itens (
  kit_cod    text not null references kits(cod) on delete cascade,
  item_cod   text not null references itens(cod) on delete restrict,
  quantidade integer not null check (quantidade > 0),
  primary key (kit_cod, item_cod)
);

create table frota (
  cod               text primary key,
  nome              text not null,
  tipo              text not null,
  placa             text,
  capacidade_kg     integer not null default 0,
  capacidade_cases  integer not null default 0,
  lugares           integer not null default 2 check (lugares >= 1),
  observacao        text,
  em_manutencao     boolean not null default false
);

-- ---------- pipeline comercial ----------
create table negocios (
  id                 uuid primary key default gen_random_uuid(),
  codigo             text unique not null,
  titulo             text not null,
  cliente_id         uuid references clientes(id) on delete set null,
  etapa              etapa_negocio not null default 'qualificacao',
  temperatura        temperatura_lead not null default 'morno',
  recorrente         boolean not null default false,
  eventos_anteriores integer not null default 0,
  tipo_evento        text default 'Corporativo',
  origem             text,
  responsavel_id     uuid references perfis(id) on delete set null,
  local_nome         text,
  sala               text,
  endereco           text,
  cidade             text,
  publico            integer default 0,
  prazo_decisao      date,
  montagem           date,
  montagem_hora      time default '07:00',
  evento_inicio      date,
  evento_inicio_hora time default '19:00',
  evento_fim         date,
  evento_fim_hora    time default '23:00',
  desmontagem        date,
  desmontagem_hora   time default '22:00',
  valor              numeric(14,2) not null default 0,
  criado_em          timestamptz not null default now(),
  atualizado_em      timestamptz not null default now(),
  constraint janela_valida check (desmontagem is null or montagem is null or desmontagem >= montagem)
);

create table negocio_sala (
  negocio_id  uuid primary key references negocios(id) on delete cascade,
  area_m2     numeric(10,2) default 0,
  pe_direito  numeric(6,2)  default 0,
  ancoragem   ancoragem_sala not null default 'confirmar',
  carga_piso  numeric(10,2) default 500,
  energia_kva numeric(10,2) default 0,
  pontos      integer default 0,
  acesso      text,
  elevador    boolean default false,
  observacao  text
);
comment on table negocio_sala is 'O que o cliente informou na ligação; a visita técnica confirma.';

create table briefing_blocos (
  negocio_id uuid not null references negocios(id) on delete cascade,
  bloco      bloco_briefing not null,
  incluso    boolean not null default false,
  porte      text,
  observacao text,
  primary key (negocio_id, bloco)
);
comment on column briefing_blocos.porte is 'Ideia central do bloco; as quantidades saem do porte e a produção refina.';

create table briefing_notas (
  id         uuid primary key default gen_random_uuid(),
  negocio_id uuid not null references negocios(id) on delete cascade,
  autor_id   uuid references perfis(id) on delete set null,
  texto      text not null,
  criado_em  timestamptz not null default now()
);

create table visitas_tecnicas (
  negocio_id uuid primary key references negocios(id) on delete cascade,
  realizada  boolean not null default false,
  data       date,
  hora       time,
  resumo     text
);
create table vt_participantes (
  negocio_id uuid not null references negocios(id) on delete cascade,
  perfil_id  uuid not null references perfis(id) on delete cascade,
  primary key (negocio_id, perfil_id)
);
create table vt_checklist (
  id         uuid primary key default gen_random_uuid(),
  negocio_id uuid not null references negocios(id) on delete cascade,
  ordem      integer not null default 0,
  texto      text not null,
  concluido  boolean not null default false
);
create table vt_fotos (
  id           uuid primary key default gen_random_uuid(),
  negocio_id   uuid not null references negocios(id) on delete cascade,
  storage_path text not null,
  legenda      text,
  enviado_por  uuid references perfis(id) on delete set null,
  criado_em    timestamptz not null default now()
);
comment on column vt_fotos.storage_path is 'Caminho no bucket vt-fotos do Supabase Storage.';

create table projetos_3d (
  negocio_id    uuid primary key references negocios(id) on delete cascade,
  necessario    boolean not null default false,
  status        status_3d not null default 'Não solicitado',
  responsavel_id uuid references perfis(id) on delete set null,
  prazo         date,
  revisoes      integer not null default 0,
  arquivo       text,
  retorno       text
);

create table orcamentos (
  negocio_id    uuid primary key references negocios(id) on delete cascade,
  desconto      numeric(5,2) not null default 0 check (desconto between 0 and 100),
  condicoes     text,
  validade      date,
  observacao    text,
  probabilidade integer not null default 50 check (probabilidade between 0 and 100),
  previsao      date,
  concorrentes  text
);

create table orcamento_linhas (
  id              uuid primary key default gen_random_uuid(),
  negocio_id      uuid not null references negocios(id) on delete cascade,
  tipo            tipo_linha_orc not null,
  item_cod        text references itens(cod) on delete restrict,
  descricao       text not null,
  categoria       text not null,
  quantidade      numeric(12,2) not null default 1 check (quantidade >= 0),
  diarias         integer not null default 1 check (diarias >= 1),
  valor_unitario  numeric(12,2) not null default 0 check (valor_unitario >= 0),
  cobranca        cobranca_linha not null default 'diaria',
  fornecedor      text,
  observacao      text,
  ordem           integer not null default 0,
  constraint estoque_tem_item check (tipo <> 'estoque' or item_cod is not null)
);
comment on table orcamento_linhas is 'Linhas de estoque viram o escopo da OS; linhas externas viram o descritivo de terceiros.';

create table fechamentos (
  negocio_id   uuid primary key references negocios(id) on delete cascade,
  reuniao      date,
  hora         time,
  decisoes     text,
  aprovado     boolean not null default false,
  aprovado_por uuid references perfis(id) on delete set null,
  aprovado_em  timestamptz
);
create table fechamento_participantes (
  negocio_id uuid not null references negocios(id) on delete cascade,
  perfil_id  uuid not null references perfis(id) on delete cascade,
  primary key (negocio_id, perfil_id)
);
create table fechamento_pauta (
  id         uuid primary key default gen_random_uuid(),
  negocio_id uuid not null references negocios(id) on delete cascade,
  ordem      integer not null default 0,
  texto      text not null,
  revisado   boolean not null default false
);

-- ---------- ordens de serviço ----------
create table ordens_venda (
  id            uuid primary key default gen_random_uuid(),
  codigo        text unique not null,
  negocio_id    uuid references negocios(id) on delete set null,
  cliente_id    uuid references clientes(id) on delete set null,
  evento        text not null,
  local_nome    text,
  cidade        text,
  publico       integer default 0,
  area_m2       numeric(10,2) default 0,
  montagem      date not null,
  evento_inicio date,
  evento_fim    date,
  desmontagem   date not null,
  valor         numeric(14,2) not null default 0,
  status        status_os not null default 'Aguardando produção',
  descritivo    text,
  criado_em     timestamptz not null default now(),
  constraint janela_os check (desmontagem >= montagem)
);
alter table negocios add column os_id uuid references ordens_venda(id) on delete set null;

create table os_produtores (
  os_id       uuid not null references ordens_venda(id) on delete cascade,
  perfil_id   uuid not null references perfis(id) on delete cascade,
  responsavel boolean not null default false,
  primary key (os_id, perfil_id)
);
create unique index um_responsavel_por_os on os_produtores(os_id) where responsavel;

create table os_itens (
  id               uuid primary key default gen_random_uuid(),
  os_id            uuid not null references ordens_venda(id) on delete cascade,
  item_cod         text not null references itens(cod) on delete restrict,
  quantidade       integer not null check (quantidade > 0),
  quantidade_aerea integer,
  observacao       text,
  unique (os_id, item_cod),
  constraint aerea_cabe check (quantidade_aerea is null or quantidade_aerea between 0 and quantidade)
);
comment on column os_itens.quantidade_aerea is
  'NULL = ainda não classificado (fica fora dos dois memoriais). 0 = tudo no solo. =quantidade = tudo suspenso.';

create table os_ancoragens (
  id         uuid primary key default gen_random_uuid(),
  os_id      uuid not null references ordens_venda(id) on delete cascade,
  nome       text not null,
  quantidade integer not null check (quantidade > 0),
  wll_kgf    numeric(10,2) not null check (wll_kgf >= 0)
);
comment on table os_ancoragens is 'Pontos que o local libera, por grupo de capacidade. Base do memorial aéreo.';

create table os_memorial (
  os_id                   uuid primary key references ordens_venda(id) on delete cascade,
  area_apoio              numeric(10,2) not null default 0,
  carga_admissivel        numeric(10,2) not null default 500,
  carga_pontual_admissivel numeric(10,2) not null default 600,
  sobrecarga_publico      numeric(10,2) not null default 300,
  apoios_por_equipamento  integer not null default 4 check (apoios_por_equipamento >= 1),
  torre_solo              boolean not null default false,
  solo_concluido          boolean not null default false,
  fator_dinamico          numeric(4,2) not null default 1.20,
  fator_desbalanceamento  numeric(4,2) not null default 1.25,
  wll_acessorio           numeric(10,2) not null default 2000,
  fs_minimo               numeric(4,1) not null default 5,
  vao_livre               numeric(6,2) not null default 10,
  aereo_concluido         boolean not null default false
);

create table os_logistica (
  os_id      uuid primary key references ordens_venda(id) on delete cascade,
  observacao text
);
create table os_viagens (
  id          uuid primary key default gen_random_uuid(),
  os_id       uuid not null references ordens_venda(id) on delete cascade,
  veiculo_cod text not null references frota(cod) on delete restrict,
  motorista   text,
  saida       date,
  hora        time,
  retorno     date,
  observacao  text,
  unique (os_id, veiculo_cod)
);
create table viagem_equipe (
  id        uuid primary key default gen_random_uuid(),
  viagem_id uuid not null references os_viagens(id) on delete cascade,
  nome      text not null,
  funcao    text not null,
  perfil_id uuid references perfis(id) on delete set null
);

-- ---------- logística de estoque ----------
create table ordens_carga (
  id            uuid primary key default gen_random_uuid(),
  codigo        text unique not null,
  os_id         uuid references ordens_venda(id) on delete set null,
  evento_avulso text,
  status        status_carga not null default 'Liberada',
  data_carga    date not null,
  hora_carga    time default '07:00',
  data_descarga date not null,
  veiculo       text,
  equipe        text,
  conferente_id uuid references perfis(id) on delete set null,
  observacao    text,
  criado_em     timestamptz not null default now(),
  constraint janela_carga check (data_descarga >= data_carga)
);
create table osc_itens (
  id              uuid primary key default gen_random_uuid(),
  ordem_carga_id  uuid not null references ordens_carga(id) on delete cascade,
  item_cod        text not null references itens(cod) on delete restrict,
  quantidade      integer not null check (quantidade > 0),
  unique (ordem_carga_id, item_cod)
);

create table movimentos (
  id             uuid primary key default gen_random_uuid(),
  codigo         text unique not null,
  data           date not null,
  tipo           tipo_movimento not null,
  ordem_carga_id uuid references ordens_carga(id) on delete set null,
  referencia     text,
  usuario_id     uuid references perfis(id) on delete set null,
  criado_em      timestamptz not null default now()
);
create table movimento_linhas (
  id            uuid primary key default gen_random_uuid(),
  movimento_id  uuid not null references movimentos(id) on delete cascade,
  item_cod      text not null references itens(cod) on delete restrict,
  quantidade    integer not null check (quantidade >= 0),
  avaria        integer not null default 0 check (avaria >= 0)
);
comment on table movimentos is 'Livro razão do estoque: SAIDA na data da carga, ENTRADA na data da descarga.';

-- ---------- agenda, notas e comunicação ----------
create table compromissos (
  id           uuid primary key default gen_random_uuid(),
  titulo       text not null,
  data         date not null,
  hora         time,
  duracao_min  integer default 60,
  tipo         text not null default 'reuniao',
  negocio_id   uuid references negocios(id) on delete cascade,
  os_id        uuid references ordens_venda(id) on delete cascade,
  local        text,
  observacao   text,
  criado_por   uuid references perfis(id) on delete set null,
  criado_em    timestamptz not null default now()
);
create table compromisso_responsaveis (
  compromisso_id uuid not null references compromissos(id) on delete cascade,
  perfil_id      uuid not null references perfis(id) on delete cascade,
  primary key (compromisso_id, perfil_id)
);

create table notas (
  id        uuid primary key default gen_random_uuid(),
  titulo    text not null,
  conteudo  text,
  etiquetas text[] not null default '{}',
  cor       text,
  fixada    boolean not null default false,
  escopo    escopo_nota not null default 'equipe',
  autor_id  uuid references perfis(id) on delete set null,
  os_id     uuid references ordens_venda(id) on delete set null,
  criado_em timestamptz not null default now()
);
create table nota_checklist (
  id        uuid primary key default gen_random_uuid(),
  nota_id   uuid not null references notas(id) on delete cascade,
  ordem     integer not null default 0,
  texto     text not null,
  concluido boolean not null default false
);

create table canais (
  id         uuid primary key default gen_random_uuid(),
  tipo       tipo_canal not null default 'canal',
  nome       text,
  descricao  text,
  os_id      uuid references ordens_venda(id) on delete cascade,
  criado_em  timestamptz not null default now()
);
create table canal_membros (
  canal_id  uuid not null references canais(id) on delete cascade,
  perfil_id uuid not null references perfis(id) on delete cascade,
  lido_em   timestamptz not null default now(),
  primary key (canal_id, perfil_id)
);
create table mensagens (
  id        uuid primary key default gen_random_uuid(),
  canal_id  uuid not null references canais(id) on delete cascade,
  autor_id  uuid references perfis(id) on delete set null,
  texto     text not null,
  sistema   boolean not null default false,
  criado_em timestamptz not null default now()
);

create table posts (
  id        uuid primary key default gen_random_uuid(),
  autor_id  uuid references perfis(id) on delete set null,
  texto     text not null,
  sistema   boolean not null default false,
  criado_em timestamptz not null default now()
);
create table post_curtidas (
  post_id   uuid not null references posts(id) on delete cascade,
  perfil_id uuid not null references perfis(id) on delete cascade,
  primary key (post_id, perfil_id)
);
create table post_comentarios (
  id        uuid primary key default gen_random_uuid(),
  post_id   uuid not null references posts(id) on delete cascade,
  autor_id  uuid references perfis(id) on delete set null,
  texto     text not null,
  criado_em timestamptz not null default now()
);

create table notificacoes (
  id         uuid primary key default gen_random_uuid(),
  texto      text not null,
  tipo       text not null default 'info',
  destino    papel[] not null default '{gerencia,producao,estoque}',
  tela       text,
  referencia text,
  criado_em  timestamptz not null default now()
);
create table notificacao_leituras (
  notificacao_id uuid not null references notificacoes(id) on delete cascade,
  perfil_id      uuid not null references perfis(id) on delete cascade,
  lido_em        timestamptz not null default now(),
  primary key (notificacao_id, perfil_id)
);

-- ---------- índices que o dia a dia usa ----------
create index idx_oc_janela        on ordens_carga using gist (daterange(data_carga, data_descarga, '[]'));
create index idx_oc_status        on ordens_carga(status);
create index idx_osc_item         on osc_itens(item_cod);
create index idx_os_janela        on ordens_venda(montagem, desmontagem);
create index idx_os_status        on ordens_venda(status);
create index idx_os_itens_os      on os_itens(os_id);
create index idx_negocios_etapa   on negocios(etapa);
create index idx_orc_linhas_neg   on orcamento_linhas(negocio_id);
create index idx_mensagens_canal  on mensagens(canal_id, criado_em desc);
create index idx_mov_data         on movimentos(data desc);
create index idx_viagens_veiculo  on os_viagens(veiculo_cod);
