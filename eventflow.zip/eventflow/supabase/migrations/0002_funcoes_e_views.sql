-- =============================================================
-- EventFlow · 0002 · disponibilidade, memoriais e operações de estoque
-- Aqui mora a regra central: o que está reservado numa janela
-- carga → descarga, e o que sai e volta do galpão.
-- =============================================================

-- ---------- quem sou eu ----------
create or replace function meu_papel() returns papel
language sql stable security definer set search_path = public as $$
  select papel from perfis where id = auth.uid();
$$;

create or replace function e_gerencia() returns boolean
language sql stable as $$ select coalesce(meu_papel() = 'gerencia', false) $$;
create or replace function e_producao() returns boolean
language sql stable as $$ select coalesce(meu_papel() = 'producao', false) $$;
create or replace function e_estoque() returns boolean
language sql stable as $$ select coalesce(meu_papel() = 'estoque', false) $$;

-- ---------- disponibilidade de equipamento ----------
-- Uma ordem de carga ocupa o item do dia da carga ao dia da descarga, inclusive.
create or replace function reservado(p_item text, p_de date, p_ate date, p_excluir uuid default null)
returns integer language sql stable as $$
  select coalesce(sum(i.quantidade), 0)::integer
    from ordens_carga c
    join osc_itens   i on i.ordem_carga_id = c.id
   where i.item_cod = p_item
     and c.status in ('Liberada','Em separação','Carregada')
     and (p_excluir is null or c.id <> p_excluir)
     and daterange(c.data_carga, c.data_descarga, '[]')
      && daterange(p_de,         p_ate,          '[]');
$$;

create or replace function em_campo(p_item text)
returns integer language sql stable as $$
  select coalesce(sum(i.quantidade), 0)::integer
    from ordens_carga c
    join osc_itens   i on i.ordem_carga_id = c.id
   where i.item_cod = p_item and c.status = 'Carregada';
$$;

create or replace function disponivel(p_item text, p_de date, p_ate date, p_excluir uuid default null)
returns integer language sql stable as $$
  select (it.quantidade_total - it.em_manutencao - reservado(p_item, p_de, p_ate, p_excluir))::integer
    from itens it where it.cod = p_item;
$$;

-- Grade de disponibilidade para uma janela inteira, em uma consulta.
create or replace function disponibilidade(p_de date, p_ate date)
returns table (
  cod text, nome text, categoria categoria_item,
  total integer, manutencao integer, campo integer,
  reservado integer, disponivel integer, cases_estoque integer, watts_total integer
) language sql stable as $$
  select it.cod, it.nome, it.categoria,
         it.quantidade_total, it.em_manutencao,
         em_campo(it.cod),
         reservado(it.cod, p_de, p_ate),
         it.quantidade_total - it.em_manutencao - reservado(it.cod, p_de, p_ate),
         ceil(it.quantidade_total::numeric / greatest(it.por_case,1))::integer,
         it.watts * it.quantidade_total
    from itens it
   where it.ativo
   order by it.categoria, it.nome;
$$;

-- Onde o estoque está estourado: reserva acima da capacidade na janela de alguma ordem.
create or replace view v_conflitos as
  select i.item_cod as cod, it.nome, c.data_carga as de, c.data_descarga as ate,
         reservado(i.item_cod, c.data_carga, c.data_descarga)                            as reservado,
         (it.quantidade_total - it.em_manutencao)                                        as capacidade,
         reservado(i.item_cod, c.data_carga, c.data_descarga)
           - (it.quantidade_total - it.em_manutencao)                                    as falta
    from ordens_carga c
    join osc_itens    i  on i.ordem_carga_id = c.id
    join itens        it on it.cod = i.item_cod
   where c.status in ('Liberada','Em separação','Carregada')
     and reservado(i.item_cod, c.data_carga, c.data_descarga) > (it.quantidade_total - it.em_manutencao);

-- ---------- disponibilidade de frota ----------
create or replace function veiculo_livre(p_veiculo text, p_de date, p_ate date, p_excluir_os uuid default null)
returns boolean language sql stable as $$
  select not coalesce((select em_manutencao from frota where cod = p_veiculo), true)
     and not exists (
       select 1 from os_viagens v
         join ordens_venda o on o.id = v.os_id
        where v.veiculo_cod = p_veiculo
          and o.status <> 'Encerrada'
          and (p_excluir_os is null or o.id <> p_excluir_os)
          and daterange(o.montagem, o.desmontagem, '[]') && daterange(p_de, p_ate, '[]'));
$$;

-- ---------- memoriais, calculados a partir da OS ----------
-- Linha com quantidade_aerea nula fica fora dos dois memoriais, de propósito:
-- enquanto o produtor não classifica, aquele peso não pode ser contado em lugar nenhum.
create or replace function massa_suspensa(p_os uuid) returns numeric
language sql stable as $$
  select coalesce(sum(it.peso_kg * i.quantidade_aerea), 0)
    from os_itens i join itens it on it.cod = i.item_cod
   where i.os_id = p_os and i.quantidade_aerea is not null;
$$;
create or replace function massa_apoiada(p_os uuid) returns numeric
language sql stable as $$
  select coalesce(sum(it.peso_kg * (i.quantidade - i.quantidade_aerea)), 0)
    from os_itens i join itens it on it.cod = i.item_cod
   where i.os_id = p_os and i.quantidade_aerea is not null;
$$;
create or replace function itens_sem_classificacao(p_os uuid) returns integer
language sql stable as $$
  select count(*)::integer from os_itens where os_id = p_os and quantidade_aerea is null;
$$;

create or replace view v_memorial_solo as
  select m.os_id,
         massa_apoiada(m.os_id)                                    as massa_apoiada_kgf,
         case when m.torre_solo then massa_suspensa(m.os_id) else 0 end as massa_transferida_kgf,
         massa_apoiada(m.os_id) + case when m.torre_solo then massa_suspensa(m.os_id) else 0 end as carga_total_kgf,
         m.area_apoio,
         round((massa_apoiada(m.os_id) + case when m.torre_solo then massa_suspensa(m.os_id) else 0 end)
               / nullif(m.area_apoio,0), 2)                        as distribuida_equipamento,
         m.sobrecarga_publico,
         round((massa_apoiada(m.os_id) + case when m.torre_solo then massa_suspensa(m.os_id) else 0 end)
               / nullif(m.area_apoio,0) + m.sobrecarga_publico, 2) as distribuida_projeto,
         m.carga_admissivel,
         round(((massa_apoiada(m.os_id) + case when m.torre_solo then massa_suspensa(m.os_id) else 0 end)
               / nullif(m.area_apoio,0) + m.sobrecarga_publico)
               / nullif(m.carga_admissivel,0) * 100, 1)            as utilizacao_pct,
         ((massa_apoiada(m.os_id) + case when m.torre_solo then massa_suspensa(m.os_id) else 0 end)
               / nullif(m.area_apoio,0) + m.sobrecarga_publico) <= m.carga_admissivel as aprovado
    from os_memorial m;
comment on view v_memorial_solo is 'Critério ABNT NBR 6120: distribuída de projeto ≤ admissível do piso.';

create or replace view v_memorial_aereo as
  with base as (
    select m.os_id, m.torre_solo, m.fator_dinamico, m.fator_desbalanceamento,
           m.wll_acessorio, m.fs_minimo, m.vao_livre,
           case when m.torre_solo then 0 else massa_suspensa(m.os_id) end as suspensa,
           coalesce((select sum(quantidade) from os_ancoragens where os_id = m.os_id), 0) as pontos,
           coalesce((select sum(quantidade * wll_kgf) from os_ancoragens where os_id = m.os_id), 0) as capacidade,
           (select min(wll_kgf) from os_ancoragens where os_id = m.os_id) as wll_min
      from os_memorial m)
  select os_id, torre_solo, suspensa as massa_suspensa_kgf, pontos, capacidade as capacidade_kgf,
         round(suspensa * fator_dinamico * fator_desbalanceamento, 1)                      as carga_projeto_kgf,
         round(suspensa * fator_dinamico * fator_desbalanceamento / nullif(pontos,0), 1)   as carga_por_ponto_kgf,
         round(suspensa * fator_dinamico * fator_desbalanceamento
               / nullif(pontos,0) / nullif(wll_min,0) * 100, 1)                            as utilizacao_pct,
         round(wll_acessorio * 7
               / nullif(suspensa * fator_dinamico * fator_desbalanceamento / nullif(pontos,0), 0), 1) as fs_resultante,
         round(vao_livre * 1000 / 200, 0)                                                  as flecha_admissivel_mm,
         case when torre_solo then true
              else pontos > 0
               and suspensa * fator_dinamico * fator_desbalanceamento / nullif(pontos,0) <= wll_min
               and wll_acessorio * 7
                   / nullif(suspensa * fator_dinamico * fator_desbalanceamento / nullif(pontos,0),0) >= fs_minimo
         end as aprovado
    from base;
comment on view v_memorial_aereo is 'Carga de projeto = massa × fator dinâmico × desbalanceamento, distribuída nos pontos cadastrados.';

-- ---------- volumetria e energia da OS ----------
create or replace view v_os_carga_tecnica as
  select i.os_id, it.categoria,
         sum(i.quantidade)                                                  as pecas,
         sum(ceil(i.quantidade::numeric / greatest(it.por_case,1)))::integer as cases,
         sum(it.peso_kg * i.quantidade)                                     as peso_kgf,
         sum(it.watts   * i.quantidade)                                     as consumo_w,
         round(sum(it.watts * i.quantidade) / 1000.0 / 0.8, 1)              as demanda_kva
    from os_itens i join itens it on it.cod = i.item_cod
   group by i.os_id, it.categoria;

-- ---------- sequências de numeração ----------
-- Sequência, não timestamp: duas baixas no mesmo segundo geravam o mesmo código.
create sequence if not exists seq_movimento    start 4500;
create sequence if not exists seq_ordem_carga  start 400;
create sequence if not exists seq_ordem_venda  start 200;
create sequence if not exists seq_negocio      start 1100;

create or replace function proximo_codigo(p_prefixo text, p_seq text)
returns text language sql volatile as $$
  select p_prefixo || '-' || to_char(now(),'YYYY') || '-' || lpad(nextval(p_seq)::text, 4, '0');
$$;

-- ---------- operações de estoque (RPC) ----------
-- Confirmar a carga baixa o estoque na data da carga.
create or replace function confirmar_carga(p_ordem uuid)
returns movimentos language plpgsql security definer set search_path = public as $$
declare v_oc ordens_carga; v_mov movimentos; v_falta text;
begin
  if not (e_estoque() or e_gerencia()) then
    raise exception 'Apenas estoque ou gerência podem confirmar a carga.';
  end if;
  select * into v_oc from ordens_carga where id = p_ordem for update;
  if not found then raise exception 'Ordem de carga não encontrada.'; end if;
  if v_oc.status <> 'Em separação' then
    raise exception 'A ordem precisa estar em separação (está em %).', v_oc.status;
  end if;

  select string_agg(it.nome, ', ') into v_falta
    from osc_itens i join itens it on it.cod = i.item_cod
   where i.ordem_carga_id = p_ordem
     and disponivel(i.item_cod, v_oc.data_carga, v_oc.data_descarga, p_ordem) < i.quantidade;
  if v_falta is not null then
    raise exception 'Sem saldo na janela para: %', v_falta;
  end if;

  update ordens_carga set status = 'Carregada' where id = p_ordem;

  insert into movimentos (codigo, data, tipo, ordem_carga_id, referencia, usuario_id)
  values (proximo_codigo('MOV','seq_movimento'), v_oc.data_carga, 'SAIDA', p_ordem,
          coalesce((select evento from ordens_venda where id = v_oc.os_id), v_oc.evento_avulso),
          auth.uid())
  returning * into v_mov;

  insert into movimento_linhas (movimento_id, item_cod, quantidade)
  select v_mov.id, item_cod, quantidade from osc_itens where ordem_carga_id = p_ordem;

  return v_mov;
end $$;

-- Registrar a descarga dá entrada na data da descarga; a avaria vai para manutenção.
create or replace function registrar_descarga(p_ordem uuid, p_avarias jsonb default '{}'::jsonb)
returns movimentos language plpgsql security definer set search_path = public as $$
declare v_oc ordens_carga; v_mov movimentos; r record; v_av integer;
begin
  if not (e_estoque() or e_gerencia()) then
    raise exception 'Apenas estoque ou gerência podem registrar a descarga.';
  end if;
  select * into v_oc from ordens_carga where id = p_ordem for update;
  if not found then raise exception 'Ordem de carga não encontrada.'; end if;
  if v_oc.status <> 'Carregada' then
    raise exception 'Só se dá entrada no que está carregado (está em %).', v_oc.status;
  end if;

  update ordens_carga set status = 'Retornada' where id = p_ordem;

  insert into movimentos (codigo, data, tipo, ordem_carga_id, referencia, usuario_id)
  values (proximo_codigo('MOV','seq_movimento'), v_oc.data_descarga, 'ENTRADA', p_ordem,
          coalesce((select evento from ordens_venda where id = v_oc.os_id), v_oc.evento_avulso),
          auth.uid())
  returning * into v_mov;

  for r in select item_cod, quantidade from osc_itens where ordem_carga_id = p_ordem loop
    v_av := least(coalesce((p_avarias ->> r.item_cod)::integer, 0), r.quantidade);
    insert into movimento_linhas (movimento_id, item_cod, quantidade, avaria)
    values (v_mov.id, r.item_cod, r.quantidade - v_av, v_av);
    if v_av > 0 then
      update itens set em_manutencao = em_manutencao + v_av where cod = r.item_cod;
    end if;
  end loop;

  if v_oc.os_id is not null then
    update ordens_venda set status = 'Encerrada' where id = v_oc.os_id;
  end if;
  return v_mov;
end $$;

-- Emitir a ordem de carga a partir da OS: só com os dois memoriais fechados,
-- o descritivo escrito e nenhum item sem classificação.
create or replace function gerar_ordem_carga(p_os uuid)
returns ordens_carga language plpgsql security definer set search_path = public as $$
declare v_os ordens_venda; v_mem os_memorial; v_oc ordens_carga; v_veic text; v_eq text;
begin
  if not (e_producao() or e_gerencia()) then
    raise exception 'Apenas produção ou gerência podem emitir a ordem de carga.';
  end if;
  select * into v_os from ordens_venda where id = p_os;
  if not found then raise exception 'OS não encontrada.'; end if;
  if exists (select 1 from ordens_carga where os_id = p_os) then
    raise exception 'Esta OS já possui ordem de carga.';
  end if;
  select * into v_mem from os_memorial where os_id = p_os;
  if v_mem is null or not v_mem.solo_concluido or not v_mem.aereo_concluido then
    raise exception 'Conclua os dois memoriais antes de emitir a carga.';
  end if;
  if coalesce(length(trim(v_os.descritivo)),0) < 40 then
    raise exception 'O descritivo técnico ainda não está escrito.';
  end if;
  if itens_sem_classificacao(p_os) > 0 then
    raise exception '% linha(s) do escopo ainda sem aplicação definida.', itens_sem_classificacao(p_os);
  end if;

  select string_agg(f.nome || ' · ' || coalesce(f.placa,'—'), ' + '),
         count(*) || ' veículo(s)'
    into v_veic, v_eq
    from os_viagens v join frota f on f.cod = v.veiculo_cod where v.os_id = p_os;

  insert into ordens_carga (codigo, os_id, status, data_carga, data_descarga, veiculo, equipe, observacao)
  values (proximo_codigo('OSC','seq_ordem_carga'),
          p_os, 'Liberada', v_os.montagem, v_os.desmontagem,
          coalesce(v_veic,'A definir na roteirização'), coalesce(v_eq,'A escalar'),
          'Gerada a partir de ' || v_os.codigo)
  returning * into v_oc;

  insert into osc_itens (ordem_carga_id, item_cod, quantidade)
  select v_oc.id, item_cod, quantidade from os_itens where os_id = p_os;

  update ordens_venda set status = 'Liberada' where id = p_os;
  return v_oc;
end $$;

-- ---------- perfil criado junto com o usuário ----------
create or replace function fn_novo_usuario() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  insert into perfis (id, nome, papel)
  values (new.id,
          coalesce(new.raw_user_meta_data ->> 'nome', split_part(new.email,'@',1)),
          coalesce((new.raw_user_meta_data ->> 'papel')::papel, 'producao'))
  on conflict (id) do nothing;
  return new;
end $$;
drop trigger if exists tg_novo_usuario on auth.users;
create trigger tg_novo_usuario after insert on auth.users
  for each row execute function fn_novo_usuario();

-- ---------- carimbo de atualização ----------
create or replace function fn_toca_atualizado() returns trigger
language plpgsql as $$ begin new.atualizado_em := now(); return new; end $$;
create trigger tg_negocios_atualizado before update on negocios
  for each row execute function fn_toca_atualizado();
