-- =============================================================
-- EventFlow · seed · catálogo, kits e frota
-- Rode depois das migrações. Não cria usuários: o perfil nasce
-- sozinho pelo gatilho quando alguém se cadastra no Auth.
-- =============================================================

-- ---------- catálogo, nas sete categorias ----------
insert into itens (cod, nome, categoria, unidade, peso_kg, quantidade_total, em_manutencao, diaria, por_case, watts) values
-- Estrutura
('TRS-Q30','Treliça Box Truss Q30 · 3 m','Estrutura','pç',16.5,120,4,42,6,0),
('TRS-Q40','Treliça Box Truss Q40 · 3 m','Estrutura','pç',24.0,64,0,68,4,0),
('TRS-SLV','Sleeve Block Q30 · torre','Estrutura','pç',12.0,24,0,95,4,0),
('BAS-P50','Base P50 c/ contrapeso 25 kg','Estrutura','pç',45.0,40,2,60,2,0),
('TAL-1T','Talha manual 1 t · corrente 12 m','Estrutura','pç',11.0,36,1,85,2,0),
('TAL-2T','Talha elétrica 2 t · 18 m','Estrutura','pç',38.0,12,0,290,1,750),
('SLG-2T','Sling poliéster WLL 2 t · 2 m','Estrutura','pç',0.8,200,0,12,40,0),
('MAN-3T','Manilha âncora 3,25 t','Estrutura','pç',0.6,240,0,8,60,0),
('PRT-2X1','Praticável 2×1 m c/ pé regulável','Estrutura','pç',32.0,80,3,55,8,0),
('PSO-NAV','Piso naval 18 mm 2×1 m','Estrutura','pç',28.0,90,0,38,10,0),
-- Som
('LNA-VT','Line array VT4888 · caixa','Som','pç',60.0,24,0,380,2,700),
('SUB-218','Subwoofer duplo 18"','Som','pç',78.0,16,1,260,1,1400),
('CON-M32','Console digital M32','Som','pç',21.0,6,0,450,1,180),
('MIC-SF','Microfone sem fio · bastão + headset','Som','cj',2.4,20,1,110,1,40),
('MON-P12','Monitor de palco 12"','Som','pç',24.0,12,0,130,2,400),
-- Luz
('MOV-B230','Moving Beam 230 · 7R','Luz','pç',18.5,48,2,120,2,280),
('MOV-W575','Moving Wash LED 575','Luz','pç',22.0,36,0,145,2,575),
('PAR-18','PAR LED 18×12 W RGBWA','Luz','pç',3.2,160,6,35,8,220),
('MES-AVO','Mesa Avolites Tiger Touch II','Luz','pç',14.0,4,0,520,1,90),
('RCK-DIM','Rack dimmer 12 canais','Luz','pç',26.0,10,0,190,1,100),
-- Vídeo
('LED-P39','Painel LED P3.9 · 0,5×0,5 m','Vídeo','pç',8.5,240,8,95,20,90),
('PRC-600','Processador LED Novastar VX600','Vídeo','pç',6.0,6,0,320,1,80),
('CAM-PTZ','Câmera PTZ Full HD c/ controle','Vídeo','pç',4.5,8,0,280,2,60),
('CAM-4K','Câmera 4K c/ lente zoom e CCU','Vídeo','pç',6.2,6,0,650,1,90),
('TRI-PRO','Tripé profissional c/ cabeça fluida','Vídeo','pç',9.0,12,1,90,2,0),
('SWT-4K','Switcher de vídeo 4K · 8 entradas','Vídeo','pç',8.0,3,0,720,1,150),
('ENC-STR','Encoder de streaming multiplataforma','Vídeo','pç',4.0,4,0,480,1,120),
('MON-REF','Monitor de referência 24"','Vídeo','pç',5.5,10,0,160,2,65),
('INT-WL','Intercom sem fio · base + 4 beltpacks','Vídeo','cj',7.0,4,0,340,1,60),
('LNK-FIB','Kit de fibra óptica SDI · 100 m','Vídeo','cj',12.0,6,0,190,1,0),
('PAS-SDI','Passador SDI ⇄ HDMI c/ scaler','Vídeo','pç',1.2,12,0,85,4,25),
-- Cenografia
('CEN-PNL','Painel cenográfico 1 × 2,5 m','Cenografia','pç',22.0,120,4,48,6,0),
('CEN-TST','Testeira tensionada 4 × 1 m','Cenografia','pç',8.0,30,0,120,4,0),
('CEN-BKD','Backdrop tensionado 6 × 3 m','Cenografia','pç',14.0,18,0,260,2,0),
('CEN-TAP','Forração / carpete · 20 m²','Cenografia','rolo',28.0,40,0,90,1,0),
('TND-10','Tenda piramidal 10 × 10 m','Cenografia','cj',380.0,6,0,2400,1,0),
('CAD-TIF','Cadeira Tiffany c/ almofada','Cenografia','pç',3.5,600,24,14,20,0),
('MES-BIS','Mesa bistrô c/ capa','Cenografia','pç',12.0,120,0,45,6,0),
('LNG-SOF','Sofá lounge 2 lugares','Cenografia','pç',40.0,24,2,190,1,0),
-- Internet
('NET-LNK','Link dedicado 500 Mbps · ativação','Internet','cj',2.0,4,0,1800,1,0),
('NET-RTR','Roteador corporativo c/ failover 4G','Internet','pç',3.2,6,0,320,2,30),
('NET-APX','Access point Wi-Fi 6 · uso externo','Internet','pç',1.4,24,1,140,6,25),
('NET-SWT','Switch gerenciável 24 portas PoE','Internet','pç',4.5,8,0,180,1,180),
('NET-CAB','Kit de cabeamento de rede · 100 m','Internet','cj',9.0,12,0,70,1,0),
-- Extras
('GER-180','Gerador silenciado 180 kVA','Extras','pç',1900.0,4,1,3200,1,0),
('CLM-30','Climatizador 30.000 BTU','Extras','pç',55.0,20,0,180,1,250),
('EXT-RAD','Rádio comunicador HT · par','Extras','cj',0.8,30,2,45,10,12),
('EXT-EXT','Extintor ABC 6 kg c/ suporte','Extras','pç',12.0,40,0,35,4,0)
on conflict (cod) do nothing;

-- ---------- kits ----------
insert into kits (cod, nome, categoria, observacao) values
('KIT-VID-01','Kit de Vídeo · corte simples','Vídeo','Palestra com uma tela e gravação.'),
('KIT-VID-02','Kit de Vídeo · multicâmera','Vídeo','Corte ao vivo com PTZ e 4K, para transmissão.'),
('KIT-SOM-01','Kit de Som · fala','Som','Palestra, congresso e cerimônia sem banda.'),
('KIT-SOM-02','Kit de Som · show','Som','Line array completo com monitoração de palco.'),
('KIT-LUZ-01','Kit de Luz · cênica','Luz','Wash e realce para palco de palestra.'),
('KIT-LUZ-02','Kit de Luz · show','Luz','Beam, wash e PAR para show e festival.'),
('KIT-RIG-01','Kit de Rigging · 8 pontos','Estrutura','Acessórios de içamento para um grid de 8 pontos.'),
('KIT-NET-01','Kit de Internet · público','Internet','Wi-Fi para plateia, com link dedicado.')
on conflict (cod) do nothing;

insert into kit_itens (kit_cod, item_cod, quantidade) values
('KIT-VID-01','SWT-4K',1),('KIT-VID-01','PAS-SDI',2),('KIT-VID-01','MON-REF',2),
('KIT-VID-01','ENC-STR',1),('KIT-VID-01','INT-WL',1),('KIT-VID-01','LNK-FIB',2),
('KIT-VID-02','SWT-4K',1),('KIT-VID-02','PAS-SDI',4),('KIT-VID-02','CAM-PTZ',2),
('KIT-VID-02','CAM-4K',2),('KIT-VID-02','TRI-PRO',3),('KIT-VID-02','MON-REF',4),
('KIT-VID-02','ENC-STR',1),('KIT-VID-02','INT-WL',2),('KIT-VID-02','LNK-FIB',2),
('KIT-SOM-01','CON-M32',1),('KIT-SOM-01','MIC-SF',2),('KIT-SOM-01','LNA-VT',2),('KIT-SOM-01','MON-P12',2),
('KIT-SOM-02','LNA-VT',12),('KIT-SOM-02','SUB-218',8),('KIT-SOM-02','CON-M32',2),
('KIT-SOM-02','MON-P12',6),('KIT-SOM-02','MIC-SF',6),
('KIT-LUZ-01','PAR-18',36),('KIT-LUZ-01','MOV-W575',8),('KIT-LUZ-01','MES-AVO',1),('KIT-LUZ-01','RCK-DIM',1),
('KIT-LUZ-02','MOV-B230',16),('KIT-LUZ-02','MOV-W575',12),('KIT-LUZ-02','PAR-18',40),
('KIT-LUZ-02','MES-AVO',1),('KIT-LUZ-02','RCK-DIM',2),
('KIT-RIG-01','TAL-1T',8),('KIT-RIG-01','SLG-2T',24),('KIT-RIG-01','MAN-3T',28),
('KIT-NET-01','NET-LNK',1),('KIT-NET-01','NET-RTR',1),('KIT-NET-01','NET-APX',8),
('KIT-NET-01','NET-SWT',1),('KIT-NET-01','NET-CAB',2)
on conflict do nothing;

-- ---------- frota ----------
insert into frota (cod, nome, tipo, placa, capacidade_kg, capacidade_cases, lugares, observacao) values
('VEI-01','Carreta sider 15 m','Carreta','QAX-2B09',24000,180,2,'Só entra em doca nivelada. Precisa de pátio para manobra.'),
('VEI-02','Truck baú 8 t','Truck baú','PLK-7E42',12000,90,3,null),
('VEI-03','Truck baú 8 t','Truck baú','RTM-4C17',12000,90,3,null),
('VEI-04','VUC 3/4 baú','VUC 3/4','SBG-9J55',3500,28,3,'Acessa garagem com 2,90 m de altura.'),
('VEI-05','Van de equipe','Van de equipe','HJU-1D80',800,4,9,'Transporte de pessoal, sem carga pesada.'),
('VEI-06','Munck 12 t','Munck','TQP-6F31',6000,10,2,'Para içamento de torre e gerador.'),
('VEI-07','Fiorino de apoio','Utilitário de apoio','MZK-2A44',650,4,2,'Compras de última hora e reposição.')
on conflict (cod) do nothing;

-- ---------- clientes de exemplo ----------
insert into clientes (nome, tipo, documento, contato, telefone, cidade, desde) values
('Vivo · Telefônica Brasil','Corporativo','02.558.157/0001-62','Renata Prado','(11) 99812-4400','São Paulo · SP','2021'),
('Banco Bradesco','Corporativo','60.746.948/0001-12','Marcos Teixeira','(11) 99745-1180','Osasco · SP','2019'),
('Ateliê Cerimônias','Social','31.884.220/0001-08','Bruna Lisboa','(11) 98110-6622','Itu · SP','2022'),
('Prefeitura de Campinas','Público','51.885.242/0001-40','Sec. de Cultura','(19) 3236-8000','Campinas · SP','2024'),
('Ambev','Corporativo','07.526.557/0001-00','Felipe Nakano','(11) 99303-7712','São Paulo · SP','2020'),
('Instituto Sonhar','Terceiro setor','18.402.771/0001-55','Cláudia Menezes','(11) 97402-3388','São Paulo · SP','2023'),
('Feira Hospitalar Brasil','Corporativo','44.120.906/0001-31','Ivan Correia','(11) 99615-0043','São Paulo · SP','2025')
on conflict do nothing;

-- ---------- canais fixos de conversa ----------
insert into canais (tipo, nome, descricao) values
('canal','Geral · Operação','Avisos que valem para o time inteiro'),
('canal','Galpão e frota','Separação, veículos e conferência')
on conflict do nothing;

-- ---------- bucket das fotos de visita técnica ----------
insert into storage.buckets (id, name, public)
values ('vt-fotos','vt-fotos', false)
on conflict (id) do nothing;

create policy "vt fotos leitura" on storage.objects for select to authenticated
  using (bucket_id = 'vt-fotos' and (e_gerencia() or e_producao()));
create policy "vt fotos envio" on storage.objects for insert to authenticated
  with check (bucket_id = 'vt-fotos' and (e_gerencia() or e_producao()));
create policy "vt fotos remocao" on storage.objects for delete to authenticated
  using (bucket_id = 'vt-fotos' and (e_gerencia() or e_producao()));
