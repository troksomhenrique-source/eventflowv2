# EventFlow

ERP + CRM para locadora de eventos corporativos e sociais.

```
eventflow.html                        aplicação inteira, um arquivo
supabase/
  migrations/0001_tipos_e_tabelas.sql esquema
  migrations/0002_funcoes_e_views.sql disponibilidade, memoriais e operações de estoque
  migrations/0003_rls.sql             permissões dos três perfis
  seed.sql                            catálogo, kits, frota e clientes
```

O HTML roda sozinho, guardando tudo no navegador de quem abre. O Supabase entra
quando a operação precisa ser compartilhada — é o passo descrito no fim deste arquivo.

## Subir o banco

**Pelo painel do Supabase** — SQL Editor, cole e rode na ordem: `0001`, `0002`, `0003`, `seed.sql`.

**Pelo CLI:**

```bash
supabase init
supabase link --project-ref SEU_PROJECT_REF
supabase db push          # aplica as migrações
psql "$DATABASE_URL" -f supabase/seed.sql
```

## Os três perfis

O papel fica em `perfis.papel` e governa todo o RLS. Quando alguém se cadastra no
Auth, o gatilho `tg_novo_usuario` cria o perfil; o papel vem de
`raw_user_meta_data.papel`, ou entra como `producao`.

```sql
update perfis set papel = 'gerencia', cargo = 'Diretora de Operações'
 where id = (select id from auth.users where email = 'patricia@sua-empresa.com.br');
```

| | gerência | produção | estoque |
|---|---|---|---|
| Pipeline, orçamento, fechamento | escreve | lê o briefing e a VT | — |
| Visita técnica e projeto 3D | escreve | **escreve** | — |
| OS: escopo, pontos, memoriais, logística | escreve | **escreve** | lê |
| Inventário, kits e frota | escreve | lê | **escreve** |
| Ordem de carga, baixa e retorno | escreve | lê | **escreve** |
| Valores | vê | **não vê** | **não vê** |

O preço não é escondido por RLS — RLS filtra linha, não coluna, e no Supabase todo
mundo chega como o mesmo papel de banco. A separação é por view: o app lê `v_itens`
e `v_ordens_venda`, que anulam `diaria` e `valor` para quem não é gerência, e as
tabelas cruas ficam fechadas para leitura. `orcamentos` e `orcamento_linhas`, onde
mora a proposta inteira, são bloqueadas por RLS mesmo.

## O que o banco calcula

**Disponibilidade por janela** — a regra central do negócio. Um item fica reservado
do dia da carga ao dia da descarga, inclusive, enquanto a ordem estiver Liberada,
Em separação ou Carregada:

```sql
select * from disponibilidade('2026-09-28','2026-10-03');
select disponivel('LED-P39','2026-09-28','2026-10-03');
select * from v_conflitos;        -- onde a reserva passou da capacidade
```

**Frota** — o mesmo princípio para veículos, pela janela da OS:

```sql
select veiculo_livre('VEI-01','2026-09-28','2026-10-02');
```

**Memoriais** — saem do escopo da OS, não de campos digitados:

```sql
select * from v_memorial_solo  where os_id = :os;   -- kgf/m² contra o limite do piso
select * from v_memorial_aereo where os_id = :os;   -- carga por ponto, FS, flecha
select * from v_os_carga_tecnica where os_id = :os; -- cases, peso e kVA por categoria
```

`os_itens.quantidade_aerea` é o campo que decide onde cada linha entra:

- `= quantidade` → tudo suspenso, vai para o memorial aéreo
- `= 0` → tudo apoiado, vai para o memorial de solo
- `NULL` → **ainda não classificado**, fica fora dos dois de propósito

Um moving pode subir no grid num evento e ficar no chão no outro, por isso a
aplicação é da linha da OS e não do cadastro do item. Enquanto houver linha em
`NULL`, `gerar_ordem_carga` se recusa a emitir.

**Operações de estoque** — são funções, não `update` solto, porque cada uma
escreve o livro razão junto:

```sql
select gerar_ordem_carga(:os);                 -- exige memoriais e descritivo prontos
select confirmar_carga(:ordem);                -- baixa na data da carga
select registrar_descarga(:ordem, '{"PAR-18":2}'::jsonb);  -- entrada, com avarias
```

A avaria informada na descarga não volta ao saldo: vai para `itens.em_manutencao`.

## Ligar o HTML no Supabase

O app guarda o estado em `S` e persiste em `localStorage` por `save()` / `load()`.
Para trocar por Supabase, carregue o cliente antes do script do app e substitua
essas duas funções:

```html
<script src="https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2"></script>
<script>
  const sb = supabase.createClient('https://SEU.supabase.co', 'SUA_ANON_KEY');
</script>
```

O caminho mais curto é ir por módulo, começando pelo inventário, que é o que mais
gente usa ao mesmo tempo:

```js
async function carregarInventario() {
  const [{ data: itens }, { data: kits }, { data: frota }] = await Promise.all([
    sb.from('v_itens').select('*'),
    sb.from('kits').select('*, kit_itens(item_cod, quantidade)'),
    sb.from('frota').select('*'),
  ]);
  S.cat   = itens.map(i => ({ cod:i.cod, nome:i.nome, cat:i.categoria, un:i.unidade,
                              peso:+i.peso_kg, porCase:i.por_case, watts:i.watts,
                              diaria:+(i.diaria ?? 0), total:i.quantidade_total,
                              manut:i.em_manutencao }));
  S.kits  = kits.map(k => ({ cod:k.cod, nome:k.nome, cat:k.categoria, obs:k.observacao,
                             itens:k.kit_itens.map(x => ({ cod:x.item_cod, qtd:x.quantidade })) }));
  S.frota = frota.map(v => ({ cod:v.cod, nome:v.nome, tipo:v.tipo, placa:v.placa,
                              capKg:v.capacidade_kg, capCases:v.capacidade_cases,
                              lugares:v.lugares, obs:v.observacao, manut:v.em_manutencao }));
  render();
}
```

Duas coisas mudam de lugar nessa passagem, e vale fazer de uma vez:

1. **Disponibilidade** deixa de ser calculada no navegador e passa a ser a função
   do banco. Troque `disponivel()` por `sb.rpc('disponibilidade', { p_de, p_ate })`
   — assim dois produtores orçando ao mesmo tempo veem o mesmo saldo.
2. **Fotos da visita técnica** saem do `localStorage` para o bucket `vt-fotos`:
   `sb.storage.from('vt-fotos').upload(caminho, arquivo)`, guardando o caminho em
   `vt_fotos.storage_path`.

Para o chat e o mural ficarem vivos entre as pessoas, assine as tabelas:

```js
sb.channel('operacao')
  .on('postgres_changes', { event:'INSERT', schema:'public', table:'mensagens' },
      ({ new: m }) => { S.msgs.push(m); render(); })
  .subscribe();
```

## Numeração

Os códigos usam sequências, para dois usuários simultâneos nunca receberem o mesmo:

```sql
select proximo_codigo('OSV','seq_ordem_venda');   -- OSV-2026-0201
select proximo_codigo('N',  'seq_negocio');       -- N-2026-1101
```

`seq_ordem_carga`, `seq_ordem_venda`, `seq_negocio` e `seq_movimento` já vêm criadas.
A ordem de carga e os movimentos se numeram sozinhos dentro das funções.
